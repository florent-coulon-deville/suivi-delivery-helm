{{/*
Nom du chart (ou nameOverride).
*/}}
{{- define "suivi-delivery-front-next.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Nom complet des objets : <installation>-<chart>, ou seulement <installation> s'il contient déjà
le nom du chart (ou fullnameOverride). Coupé à 63 caractères : limite de certains noms
Kubernetes (règles des noms DNS).
*/}}
{{- define "suivi-delivery-front-next.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Nom et version du chart, pour le label helm.sh/chart.
*/}}
{{- define "suivi-delivery-front-next.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Labels communs : à mettre sur chaque objet (metadata.labels). Contient selectorLabels.
*/}}
{{- define "suivi-delivery-front-next.labels" -}}
helm.sh/chart: {{ include "suivi-delivery-front-next.chart" . }}
{{ include "suivi-delivery-front-next.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Labels de sélection : seulement ceux qui ne changent jamais (pas la version), pour les
sélecteurs. Le sélecteur d'un Deployment ne peut plus être modifié après sa création.
*/}}
{{- define "suivi-delivery-front-next.selectorLabels" -}}
app.kubernetes.io/name: {{ include "suivi-delivery-front-next.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Nom du compte de service : créé par le chart (nom complet ou serviceAccount.name),
ou existant (serviceAccount.name, sinon « default »).
*/}}
{{- define "suivi-delivery-front-next.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "suivi-delivery-front-next.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{- /*
Identifiants des registres privés, au format Docker (contenu de .dockerconfigjson), en JSON :
  {"auths": {"ghcr.io": {"username": …, "password": <token>, "auth": base64(username:token)}}}
Seuls les registres qui ont un token (values.secret.yaml) sont repris.
*/ -}}
{{- define "suivi-delivery-front-next.registryAuths" -}}
{{- $auths := dict }}
{{- range $name, $registry := .Values.registries }}
  {{- if $registry.token }}
    {{- $username := required (printf "registries.%s.username est obligatoire quand un token est indiqué" $name) $registry.username }}
    {{- $_ := set $auths $registry.server (dict
          "username" $username
          "password" $registry.token
          "auth"     (printf "%s:%s" $username $registry.token | b64enc)) }}
  {{- end }}
{{- end }}
{{- dict "auths" $auths | toJson }}
{{- end }}

{{- /*
Renvoie « true » si au moins un registre a un token, sinon rien
(jamais « false » : un texte non vide est considéré comme vrai par un if).
*/ -}}
{{- define "suivi-delivery-front-next.hasRegistrySecret" -}}
{{- $config := include "suivi-delivery-front-next.registryAuths" . | fromJson }}
{{- if $config.auths }}true{{ end }}
{{- end }}

{{- /*
Nom du Secret des registres.
*/ -}}
{{- define "suivi-delivery-front-next.registrySecretName" -}}
{{- printf "%s-registry" (include "suivi-delivery-front-next.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- /*
imagePullSecrets d'un pod : le Secret des registres créé par ce chart (s'il existe), puis les
Secrets existants listés dans .Values.imagePullSecrets. Rien si les deux sont vides.
Utilisé par le test Helm (le Deployment écrit la même logique directement).
*/ -}}
{{- define "suivi-delivery-front-next.imagePullSecrets" -}}
{{- $secrets := list }}
{{- if include "suivi-delivery-front-next.hasRegistrySecret" . }}
{{- $secrets = append $secrets (dict "name" (include "suivi-delivery-front-next.registrySecretName" .)) }}
{{- end }}
{{- $secrets = concat $secrets (.Values.imagePullSecrets | default list) }}
{{- with $secrets }}
imagePullSecrets:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- end }}

{{- /*
Nom de la ConfigMap du fichier de réglages (.Values.config) : <fullname>-config.
*/ -}}
{{- define "suivi-delivery-front-next.configMapName" -}}
{{- printf "%s-config" (include "suivi-delivery-front-next.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}
