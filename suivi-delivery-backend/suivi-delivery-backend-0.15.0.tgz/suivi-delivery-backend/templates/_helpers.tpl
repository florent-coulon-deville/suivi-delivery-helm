{{/*
Nom du chart (ou nameOverride).
*/}}
{{- define "suivi-delivery-backend.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Nom complet des objets : <installation>-<chart>, ou seulement <installation> s'il contient déjà
le nom du chart (ou fullnameOverride). Coupé à 63 caractères : limite de certains noms
Kubernetes (règles des noms DNS).
*/}}
{{- define "suivi-delivery-backend.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Nom et version du chart, pour le label helm.sh/chart.
*/}}
{{- define "suivi-delivery-backend.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Labels communs : à mettre sur chaque objet (metadata.labels). Contient selectorLabels.
*/}}
{{- define "suivi-delivery-backend.labels" -}}
helm.sh/chart: {{ include "suivi-delivery-backend.chart" . }}
{{ include "suivi-delivery-backend.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Labels de sélection : seulement ceux qui ne changent jamais (pas la version), pour les
sélecteurs. Le sélecteur d'un Deployment ne peut plus être modifié après sa création.
*/}}
{{- define "suivi-delivery-backend.selectorLabels" -}}
app.kubernetes.io/name: {{ include "suivi-delivery-backend.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Nom du compte de service : créé par le chart (nom complet ou serviceAccount.name),
ou existant (serviceAccount.name, sinon « default »).
*/}}
{{/*
Émetteur des jetons : auth.issuer, sinon global.auth.issuer (valeur commune d'un chart chapeau,
partagée avec l'interface). Vide : l'API refuse de démarrer.
*/}}
{{- define "suivi-delivery-backend.authIssuer" -}}
{{- .Values.auth.issuer | default (dig "auth" "issuer" "" (.Values.global | default dict)) -}}
{{- end }}

{{- define "suivi-delivery-backend.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "suivi-delivery-backend.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{- /*
Identifiants des registres privés, au format Docker (contenu de .dockerconfigjson), en JSON :
  {"auths": {"ghcr.io": {"username": …, "password": <token>, "auth": base64(username:token)}}}
Seuls les registres qui ont un token (values.secret.yaml) sont repris.
*/ -}}
{{- define "suivi-delivery-backend.registryAuths" -}}
{{- $auths := dict }}
{{- range $name, $registry := .Values.registries }}
  {{- if $registry.token }}
    {{- $username := required (printf "registries.%s.username est obligatoire quand un token est indiqué" $name) $registry.username }}
    {{- $_ := set $auths $registry.server (dict
          "username" $username
          "password" $registry.token
          "auth"     (printf "%s:%s" $username $registry.token | b64enc)) }}
  {{- end }}
{{- end }}
{{- dict "auths" $auths | toJson }}
{{- end }}

{{- /*
Renvoie « true » si au moins un registre a un token, sinon rien
(jamais « false » : un texte non vide est considéré comme vrai par un if).
*/ -}}
{{- define "suivi-delivery-backend.hasRegistrySecret" -}}
{{- $config := include "suivi-delivery-backend.registryAuths" . | fromJson }}
{{- if $config.auths }}true{{ end }}
{{- end }}

{{- /*
Nom du Secret des registres.
*/ -}}
{{- define "suivi-delivery-backend.registrySecretName" -}}
{{- printf "%s-registry" (include "suivi-delivery-backend.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- /*
imagePullSecrets d'un pod : le Secret des registres créé par ce chart (s'il existe), puis les
Secrets existants listés dans .Values.imagePullSecrets. Rien si les deux sont vides.
Utilisé par le test Helm (le Deployment écrit la même logique directement).
*/ -}}
{{- define "suivi-delivery-backend.imagePullSecrets" -}}
{{- $secrets := list }}
{{- if include "suivi-delivery-backend.hasRegistrySecret" . }}
{{- $secrets = append $secrets (dict "name" (include "suivi-delivery-backend.registrySecretName" .)) }}
{{- end }}
{{- $secrets = concat $secrets (.Values.imagePullSecrets | default list) }}
{{- with $secrets }}
imagePullSecrets:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- end }}

{{- /*
Nom de la ConfigMap des variables d'environnement (.Values.config) : <fullname>-env.
« env » la distingue des ConfigMaps de fichiers de configuration (montés dans le conteneur).
*/ -}}
{{- define "suivi-delivery-backend.ConfigMapName-env" -}}
{{- printf "%s-env" (include "suivi-delivery-backend.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- /*
Nom du PersistentVolumeClaim des données : celui indiqué dans existingClaim, sinon
<fullname>-<persistence.nameSuffix> (ex. test-suivi-delivery-backend-sqlite).
*/ -}}
{{- define "suivi-delivery-backend.dataClaimName" -}}
{{- if .Values.persistence.existingClaim }}
{{- .Values.persistence.existingClaim }}
{{- else }}
{{- $suffix := required "persistence.nameSuffix est obligatoire (ex. sqlite, data)" .Values.persistence.nameSuffix }}
{{- printf "%s-%s" (include "suivi-delivery-backend.fullname" .) $suffix | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- /*
Base de données (.Values.database.engine) : contrôle des réglages, arrêt de l'installation avec un
message clair si une combinaison est impossible. Appelé par le Deployment.
*/ -}}
{{- define "suivi-delivery-backend.checkDatabase" -}}
{{- $engine := .Values.database.engine }}
{{- if not (has $engine (list "sqlite" "postgres")) }}
{{- fail (printf "database.engine doit valoir sqlite ou postgres (reçu : %v)" $engine) }}
{{- end }}
{{- if and (eq $engine "postgres") (not .Values.postgres.sidecar.enabled) }}
{{- if not .Values.database.host }}
{{- fail "base PostgreSQL externe (postgres.sidecar.enabled: false) : database.host est obligatoire" }}
{{- end }}
{{- if not .Values.database.existingSecret }}
{{- fail "base PostgreSQL externe (postgres.sidecar.enabled: false) : database.existingSecret est obligatoire (utilisateur et mot de passe)" }}
{{- end }}
{{- end }}
{{- end }}

{{- /*
« true » si PostgreSQL tourne dans le pod, à côté de l'API (conteneur sidecar).
*/ -}}
{{- define "suivi-delivery-backend.postgresSidecar" -}}
{{- if and (eq .Values.database.engine "postgres") .Values.postgres.sidecar.enabled }}true{{ end }}
{{- end }}

{{- /*
« true » si le disque persistant sert : au fichier SQLite, ou aux données du PostgreSQL du pod.
Une base PostgreSQL externe n'en a pas besoin.
*/ -}}
{{- define "suivi-delivery-backend.usesDisk" -}}
{{- if and .Values.persistence.enabled (or (eq .Values.database.engine "sqlite") (include "suivi-delivery-backend.postgresSidecar" .)) }}true{{ end }}
{{- end }}

{{- /*
Nom du Secret de la base PostgreSQL (utilisateur et mot de passe) : database.existingSecret s'il est
indiqué, sinon <fullname>-postgres (créé par le chart, PostgreSQL du pod seulement).
*/ -}}
{{- define "suivi-delivery-backend.databaseSecretName" -}}
{{- if .Values.database.existingSecret }}
{{- .Values.database.existingSecret }}
{{- else }}
{{- printf "%s-postgres" (include "suivi-delivery-backend.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
