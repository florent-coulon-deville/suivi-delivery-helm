{{/*
Nom du chart (ou nameOverride).
*/}}
{{- define "suivi-delivery-api.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Nom complet des objets : <installation>-<chart>, ou seulement <installation> s'il contient déjà
le nom du chart (ou fullnameOverride). Coupé à 63 caractères : limite de certains noms
Kubernetes (règles des noms DNS).
*/}}
{{- define "suivi-delivery-api.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Nom et version du chart, pour le label helm.sh/chart.
*/}}
{{- define "suivi-delivery-api.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Labels communs : à mettre sur chaque objet (metadata.labels). Contient selectorLabels.
*/}}
{{- define "suivi-delivery-api.labels" -}}
helm.sh/chart: {{ include "suivi-delivery-api.chart" . }}
{{ include "suivi-delivery-api.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Labels de sélection : seulement ceux qui ne changent jamais (pas la version), pour les
sélecteurs. Le sélecteur d'un Deployment ne peut plus être modifié après sa création.
*/}}
{{- define "suivi-delivery-api.selectorLabels" -}}
app.kubernetes.io/name: {{ include "suivi-delivery-api.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Nom du compte de service : créé par le chart (nom complet ou serviceAccount.name),
ou existant (serviceAccount.name, sinon « default »).
*/}}
{{- define "suivi-delivery-api.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "suivi-delivery-api.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{- /*
Identifiants des registres privés, au format Docker (contenu de .dockerconfigjson), en JSON :
  {"auths": {"ghcr.io": {"username": …, "password": <token>, "auth": base64(username:token)}}}
Seuls les registres qui ont un token (values.secret.yaml) sont repris.
*/ -}}
{{- define "suivi-delivery-api.registryAuths" -}}
{{- $auths := dict }}
{{- range $name, $registry := .Values.registries }}
  {{- if $registry.token }}
    {{- $username := required (printf "registries.%s.username est obligatoire quand un token est indiqué" $name) $registry.username }}
    {{- $_ := set $auths $registry.server (dict
          "username" $username
          "password" $registry.token
          "auth"     (printf "%s:%s" $username $registry.token | b64enc)) }}
  {{- end }}
{{- end }}
{{- dict "auths" $auths | toJson }}
{{- end }}

{{- /*
Renvoie « true » si au moins un registre a un token, sinon rien
(jamais « false » : un texte non vide est considéré comme vrai par un if).
*/ -}}
{{- define "suivi-delivery-api.hasRegistrySecret" -}}
{{- $config := include "suivi-delivery-api.registryAuths" . | fromJson }}
{{- if $config.auths }}true{{ end }}
{{- end }}

{{- /*
Nom du Secret des registres.
*/ -}}
{{- define "suivi-delivery-api.registrySecretName" -}}
{{- printf "%s-registry" (include "suivi-delivery-api.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- /*
imagePullSecrets d'un pod : le Secret des registres créé par ce chart (s'il existe), puis les
Secrets existants listés dans .Values.imagePullSecrets. Rien si les deux sont vides.
Utilisé par le test Helm (le Deployment écrit la même logique directement).
*/ -}}
{{- define "suivi-delivery-api.imagePullSecrets" -}}
{{- $secrets := list }}
{{- if include "suivi-delivery-api.hasRegistrySecret" . }}
{{- $secrets = append $secrets (dict "name" (include "suivi-delivery-api.registrySecretName" .)) }}
{{- end }}
{{- $secrets = concat $secrets (.Values.imagePullSecrets | default list) }}
{{- with $secrets }}
imagePullSecrets:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- end }}

{{- /*
Nom de la ConfigMap des variables d'environnement (.Values.config) : <fullname>-env.
« env » la distingue des ConfigMaps de fichiers de configuration (montés dans le conteneur).
*/ -}}
{{- define "suivi-delivery-api.ConfigMapName-env" -}}
{{- printf "%s-env" (include "suivi-delivery-api.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- /*
Nom du PersistentVolumeClaim des données : celui indiqué dans existingClaim, sinon
<fullname>-<persistence.nameSuffix> (ex. test-suivi-delivery-api-sqlite).
*/ -}}
{{- define "suivi-delivery-api.dataClaimName" -}}
{{- if .Values.persistence.existingClaim }}
{{- .Values.persistence.existingClaim }}
{{- else }}
{{- $suffix := required "persistence.nameSuffix est obligatoire (ex. sqlite, data)" .Values.persistence.nameSuffix }}
{{- printf "%s-%s" (include "suivi-delivery-api.fullname" .) $suffix | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}