{{/*
Nom du chart (ou nameOverride). Sous-chart avec un alias (ex. « keycloak ») : l'alias.
*/}}
{{- define "suivi-delivery-keycloak.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Nom complet : <installation>-<chart>, ou <installation> s'il contient déjà le nom du chart, ou
fullnameOverride. Coupé à 63 caractères (règles des noms DNS).
*/}}
{{- define "suivi-delivery-keycloak.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{- define "suivi-delivery-keycloak.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "suivi-delivery-keycloak.labels" -}}
helm.sh/chart: {{ include "suivi-delivery-keycloak.chart" . }}
{{ include "suivi-delivery-keycloak.selectorLabels" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "suivi-delivery-keycloak.selectorLabels" -}}
app.kubernetes.io/name: {{ include "suivi-delivery-keycloak.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Nom d'hôte public, sans « https:// » ni chemin (pour l'Ingress, la Route, la HTTPRoute).
*/}}
{{- define "suivi-delivery-keycloak.host" -}}
{{- $url := required "keycloak.hostname est obligatoire : adresse publique HTTPS de Keycloak (ex. https://auth.example.com)" .Values.keycloak.hostname -}}
{{- (urlParse $url).host -}}
{{- end }}

{{/*
Secrets : existingSecret (« tpl » : le nom peut citer .Release.Name, utile dans un chapeau),
sinon celui créé par le chart.
*/}}
{{- define "suivi-delivery-keycloak.adminSecret" -}}
{{- if .Values.admin.existingSecret -}}{{ tpl .Values.admin.existingSecret . }}{{- else -}}{{ include "suivi-delivery-keycloak.fullname" . }}-admin{{- end -}}
{{- end }}
{{- define "suivi-delivery-keycloak.adminSecretKey" -}}
{{- if .Values.admin.existingSecret -}}{{ .Values.admin.existingSecretPasswordKey }}{{- else -}}password{{- end -}}
{{- end }}
{{- define "suivi-delivery-keycloak.postgresqlSecret" -}}
{{- if .Values.postgresql.existingSecret -}}{{ tpl .Values.postgresql.existingSecret . }}{{- else -}}{{ include "suivi-delivery-keycloak.fullname" . }}-postgresql{{- end -}}
{{- end }}
{{- define "suivi-delivery-keycloak.postgresqlSecretKey" -}}
{{- if .Values.postgresql.existingSecret -}}{{ .Values.postgresql.existingSecretPasswordKey }}{{- else -}}password{{- end -}}
{{- end }}
{{/*
Secret des clients techniques (clés front, gitlab, xlr) : <fullname>-clients par défaut. Le chart
de l'interface le lit (auth.existingSecret: "{{ .Release.Name }}-keycloak-clients" dans un chapeau).
*/}}
{{- define "suivi-delivery-keycloak.clientsSecret" -}}
{{- if .Values.realm.existingSecret -}}{{ tpl .Values.realm.existingSecret . }}{{- else -}}{{ include "suivi-delivery-keycloak.fullname" . }}-clients{{- end -}}
{{- end }}
